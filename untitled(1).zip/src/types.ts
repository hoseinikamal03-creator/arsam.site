export interface ProductMedia {
  id: string;
  url: string;
  alt: string;
  isMain?: boolean;
  isVideo?: boolean;
}

export interface ColorVariant {
  name: string;
  colorNameFa: string;
  gradientClass: string;
  bgHex: string;
}

export interface Product {
  id: string;
  sku: string;
  name: string;
  category: string;
  description: string;
  price: number; // in Tomans
  discountPrice?: number;
  stock: number;
  isPublished: boolean;
  isNew?: boolean;
  rating: number;
  reviewsCount: number;
  monthlyViews: number;
  monthlyGrowthPercent: number;
  telegramLink: string;
  media: ProductMedia[];
  variants?: ColorVariant[];
  tag?: string;
  specifications?: Record<string, string>;
}

export interface CartItem {
  product: Product;
  quantity: number;
  selectedVariant?: string;
}

export interface CustomOrderData {
  fullName: string;
  phone: string;
  productName: string;
  quantity: number;
  estimatedPrice: string;
  description: string;
  createdAt?: string;
}

export type PageView = 'home' | 'products' | 'product-detail' | 'custom-order' | 'admin' | 'about';
